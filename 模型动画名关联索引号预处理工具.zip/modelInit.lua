local t = {}

t[5] = require 'war3mpq'   or {}
t[4] = require 'war3xmpq'  or {}
t[3] = require 'war3patch' or {}
t[2] = require 'war3local' or {}
t[1] = require 'userModel' or {}

function GetModelAnimIdByName(model,name)
    for i =1 ,5 do
        if t[i][model] then
            if t[i][model][name] then
                return t[i][model][name]
            end
        end
    end
    return 0;
end

return GetModelAnimIdByName
